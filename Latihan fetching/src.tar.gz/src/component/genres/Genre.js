import React, { Component } from "react";
import { createStore } from "redux";
import { Provider } from "react-redux";
import { Row, Col } from "reactstrap";
import genreReducer from "./reducers/GenreReducer";
import ListGenre from "./component/ListGenre";



const genreStore = createStore(genreReducer);
class Genre extends Component{

   

render(){
    
    return(
        <Provider store={genreStore}>
            <Row>
                <Col>
                    <ListGenre />
                </Col>
            </Row>
        </Provider>
    )
}
}

export default Genre;