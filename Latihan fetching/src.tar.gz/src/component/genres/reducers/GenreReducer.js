import { CREATE_GENRE, UPDATE_GENRE,RESET_FORM, EDIT_BUTTON, DELETE_GENRE, FETCH_COMPLETE, FETCH_DATA } from "./Actions";

const defaultFormValues = {
    id: '',
    name: ''
};

const initialState = {
    isLoading: true,
    genres: [],
    form: { ...defaultFormValues }    
}
function genreReducer(state = initialState, action) {
    const { type, payload } = action;

    switch (type) {
        
        case CREATE_GENRE:
            return { ...state, genres: state.genres.concat(payload)  };
            
            case DELETE_GENRE:
                return { ...state, genres: state.genres.filter((genre) => ( genre.id !== payload))  };
                
                case UPDATE_GENRE:
                    return { ...state, genres: state.genres.map((genre) => genre.id === payload.id ? payload : genre)};
               
                    case EDIT_BUTTON:
                    const genre = state.genres.find((genre)=> genre.id===payload);
                    return{ ...state, form: { ...genre}};
                    
                        
                        case RESET_FORM:
                            return { ...state, form: { ...defaultFormValues } }

                            case FETCH_DATA:
                                return { ...state, isLoading: true}

                                case FETCH_COMPLETE:
                                    return { ...state, isLoading: false, genres: [ ...payload]}
                        

        default:
            return { ...state }
    }
}

export default genreReducer;