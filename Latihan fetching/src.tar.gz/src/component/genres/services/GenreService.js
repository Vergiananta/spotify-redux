import client from "../../../shared/http-client/Client";

export async function getGenres(){
    const { data: { data } } = await client.get('/genres');

    return data;
}

export async function getSingleGenres(){
    const { data: { data } } = await client.get('/genres/${}');

    return data;
}