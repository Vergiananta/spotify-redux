import React, { Component } from "react";
import { Table, Card, CardHeader, Spinner } from "reactstrap";
import { FETCH_DATA, FETCH_COMPLETE } from "../reducers/Actions";
import * as Service from "../services/GenreService";
import { connect } from "react-redux";


class ListGenre extends Component{
    componentDidMount() {
        const { fetchData, fetchComplete } = this.props;

        fetchData();

        Service.getGenres().then((genres) => {
            fetchComplete(genres);
        });

    }

    generateTableRows(){
      const { genres } = this.props;
        let rows = <tr><td colSpan="2" className="text-center"> <Spinner type="grow" color="primary" /></td></tr>

        if(!this.props.isLoading){
            rows = genres.map((genre, index) => {
                return(
                    <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{genre.name}</td>
                    </tr>
                )
            });
        }

        return rows;
    }

render(){
    return(
        <Card className="shadow">
            
            <CardHeader tag="strong">
                Genres
            </CardHeader>
        
        <Table responsive striped hover className="m-0">
         <thead>
             <tr>
            <th>
                #
            </th>
            <th>
                Name
            </th>
            </tr>
        </thead>
        <tbody>
            { this.generateTableRows() }
        </tbody>
        </Table>
        </Card>
    );
}

}

function mapStateToProps(state) {
    return { ...state };
}

function mapDispatchToProps(dispatch) {
    return {
        fetchData: () => dispatch({type: FETCH_DATA}),
        fetchComplete: (payload) => dispatch({type: FETCH_COMPLETE, payload}),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ListGenre);