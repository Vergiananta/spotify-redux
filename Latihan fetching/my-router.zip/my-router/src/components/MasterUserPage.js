import React from 'react';
import {withRouter} from "react-router-dom";
import HeaderUserPage from "./HeaderUserPage";

class MasterUserPage extends React.Component{
    render(){
        return(
            <div>
                <HeaderUserPage/>
            </div>
        )
    }
}

export default MasterUserPage;