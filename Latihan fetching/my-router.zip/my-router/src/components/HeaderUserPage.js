import React from 'react';
import {withRouter} from "react-router-dom";

class HeaderUserPage extends React.Component{
    render(){
        console.log(this.props);
        return(
            <div>
                Page User Admin
            </div>
        )
    }
}

export default withRouter(HeaderUserPage);