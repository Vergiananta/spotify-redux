import React from 'react';
import {Link, Route} from "react-router-dom";
import MasterUserPage from "./MasterUserPage";


const Admin = () => {
    return (
        <div>
            <Link to="/admin/user">User Admin</Link>
            <Route path="/admin/user" component={MasterUserPage}></Route>
        </div>
    )
}

export default Admin;