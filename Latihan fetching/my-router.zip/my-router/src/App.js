import React from 'react';
import {BrowserRouter, HashRouter, Link, Redirect, Route} from 'react-router-dom';
import Header from "./components/Header";
import Admin from "./components/Admin";

const PageOne = (props) => {
    console.log(props);
    return (
        <div>
            Page 1
            <Link to="/pageTwo">Ke Halaman 2</Link>
        </div>
    )
};

const PageTwo = () => {
    return (
        <div>
            Page 2
            <Link to="/pageThree/3">Ke Halaman 3</Link>
        </div>
    )
};

const PageThree = (props) => {
    return (
        <div>
            Page {props.match.params.num}
            <Link to="/">Ke Halaman Awal</Link>
        </div>
    )
};

const routes = [
    {id: 1, path: '/pageTwo', component: PageTwo},
    {id: 2, path: '/pageThree/:num', component: PageThree},
    {id: 3, path: '/admin', component: Admin}

];

class App extends React.Component {
    state = {auth: true};

    render() {
        let a = routes.map((route) => {
            return <Route
                key={route.id}
                path={route.path} render={
                (props) => {
                    return this.state.auth ?
                        <route.component {...props}/> : <Redirect to='/'/>
                }
            }/>
        });
        console.log(a)
        return (
            <div>
                <HashRouter>
                    <Header/>
                    <div>
                        <Route path="/" exact render={(props) => <PageOne {...props} />}/>
                        {a}
                    </div>
                </HashRouter>
            </div>
        )
    }
}

export default App;
